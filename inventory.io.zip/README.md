Admin User

	•	Email: admin@example.com
	•	Password: 12345678

Regular Users

	•	Email: regularuser@example.com
	•	Password: A1b2@c3D
